// ---------------------------
// IndexedDB Setup & Helpers
// ---------------------------
const DB_NAME = 'VotingDB';
const DB_VERSION = 1;
let db = null; // IDBDatabase instance

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = (e) => reject(e.target.error);
    req.onsuccess = (e) => {
      db = e.target.result;
      resolve(db);
    };
    req.onupgradeneeded = (e) => {
      db = e.target.result;
      // Create object stores if they don't exist
      if (!db.objectStoreNames.contains('users')) {
        // keyPath 'name' to avoid duplicate usernames; you can change if needed
        db.createObjectStore('users', { keyPath: 'name' });
      }
      if (!db.objectStoreNames.contains('elections')) {
        // keyPath 'id' (we set id as Date.now() when creating)
        db.createObjectStore('elections', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('meta')) {
        // tiny store for loggedUser etc. keyPath 'key'
        db.createObjectStore('meta', { keyPath: 'key' });
      }
    };
  });
}

function promisifyRequest(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e.target.error);
  });
}

function getTransaction(storeNames, mode = 'readonly') {
  return db.transaction(storeNames, mode);
}

// CRUD helpers
async function getAllFromStore(storeName) {
  const tx = getTransaction([storeName], 'readonly');
  const store = tx.objectStore(storeName);
  return promisifyRequest(store.getAll());
}

async function putInStore(storeName, value) {
  const tx = getTransaction([storeName], 'readwrite');
  const store = tx.objectStore(storeName);
  const req = store.put(value);
  await promisifyRequest(req);
  return true;
}

async function deleteFromStore(storeName, key) {
  const tx = getTransaction([storeName], 'readwrite');
  const store = tx.objectStore(storeName);
  await promisifyRequest(store.delete(key));
}

async function clearStore(storeName) {
  const tx = getTransaction([storeName], 'readwrite');
  const store = tx.objectStore(storeName);
  await promisifyRequest(store.clear());
}

// Meta helpers (for small values like loggedUser)
async function putMeta(key, value) {
  return putInStore('meta', { key, value });
}
async function getMeta(key) {
  const tx = getTransaction(['meta'], 'readonly');
  const store = tx.objectStore('meta');
  const res = await promisifyRequest(store.get(key));
  return res?.value ?? null;
}

// ---------------------------
// App data (in-memory)
// ---------------------------
const app = document.getElementById('app');
let users = [];      // array of user objects { name, pass, idProof, photo (Blob/File), voted: {} }
let elections = [];  // array of election objects { id, title, position, status, candidates: [...] }
let loggedUser = null; // either null or user object (we'll store minimal in meta)

// ---------------------------
// Initialize: open DB + load data
// ---------------------------
async function initApp() {
  try {
    await openDB();
    await loadDataFromDB(); // populates users, elections, loggedUser
  } catch (err) {
    console.error('IndexedDB init error:', err);
    alert('IndexedDB initialization failed. Check console.');
  }
  showLogin();
}

// Load from DB into memory
async function loadDataFromDB() {
  // get all users & elections
  const dbUsers = await getAllFromStore('users');
  const dbElections = await getAllFromStore('elections');
  const dbLogged = await getMeta('loggedUser');

  users = dbUsers || [];
  elections = dbElections || [];
  loggedUser = dbLogged || null;
}

// Save in-memory arrays to DB
// We'll clear stores and re-add everything (simple sync approach).
async function saveData() {
  // users
  await clearStore('users');
  for (const u of users) {
    // store full user object (photo can be Blob/File)
    await putInStore('users', u);
  }

  // elections
  await clearStore('elections');
  for (const e of elections) {
    await putInStore('elections', e);
  }

  // meta (loggedUser)
  if (loggedUser) {
    // we don't want to store huge photo again under meta; store only username as logged info
    await putMeta('loggedUser', { name: loggedUser.name });
  } else {
    // clear key
    await deleteFromStore('meta', 'loggedUser').catch(() => { });
  }
}

// Helper to get image src - handles Blob/File or base64 string fallback
function getImageURL(maybeBlobOrString) {
  if (!maybeBlobOrString) return '';
  if (typeof maybeBlobOrString === 'string') return maybeBlobOrString; // base64
  // Blob or File
  return URL.createObjectURL(maybeBlobOrString);
}

// ---------------------------
// Your existing UI functions (slightly adapted to async where needed)
// ---------------------------

function showLogin() {
  app.innerHTML = `
  <h1>Online Voting System</h1>
  <button onclick="showAdminLogin()">Admin Login</button>
  <button onclick="showUserLogin()">User Login</button>
  <button onclick="showRegister()">Register as Voter</button>
  `;
}

function showAdminLogin() {
  app.innerHTML = `
  <h2>Admin Login</h2>
  <input type="password" id="adminPass" placeholder="Enter Admin Password" />
  <button onclick="adminLogin()">Login</button>
  <button onclick="showLogin()">Back</button>`;
}

function adminLogin() {
  const pass = document.getElementById('adminPass').value;
  if (pass === 'admin123') {
    loggedUser = { role: 'admin', name: 'admin' };
    saveData(); // persist meta
    showAdminDashboard();
  } else alert('Wrong password');
}

function showAdminDashboard() {
  document.getElementById('app').innerHTML = `<h2>Admin Dashboard</h2>
  <button onclick="createElectionForm()">Create Election</button>
  <button onclick="viewVoters()">View Voters</button>
  <div id='elist'>${renderElectionsAdmin()}</div>
  <button onclick="logout()">Logout</button>`;
}

function viewVoters() {
  if (users.length === 0) {
    app.innerHTML = `<h2>Registered Voters</h2><p>No voters registered yet.</p>
    <button onclick='showAdminDashboard()'>Back</button>`;
    return;
  }

  app.innerHTML = `
  <h2>Registered Voters</h2>
  ${users.map(u => `
    <div style="border:1px solid #ccc; padding:10px; margin:10px;">
      <img src="${getImageURL(u.photo)}" width="80" height="80" style="border-radius:50%;"><br>
      <b>Name:</b> ${u.name}<br>
      <b>ID Proof:</b> ${u.idProof}
    </div>
  `).join('')}
  <button onclick='showAdminDashboard()'>Back</button>`;
}


function createElectionForm() {
  app.innerHTML = `<h2>Create New Election</h2>
  <label>Election Title:</label>
  <input id='etitle' placeholder='Election Title' />
  <label>Position Name:</label>
  <input id='eposition' placeholder='Position' />
  <label>Start Date & Time:</label>
  <input type='datetime-local' id='estart'>
  <label>End Date & Time:</label>
  <input type='datetime-local' id='eend'>
  <div id='candidates'></div>
  <button onclick='addCandidateField()'>+ Add Candidate</button>
  <button onclick='saveElection()'>Save Election</button>
  <button onclick='showAdminDashboard()'>Cancel</button>`;
  candidateCount = 0;
  addCandidateField();
}


let candidateCount = 0;
function addCandidateField() {
  const container = document.getElementById('candidates');
  const cid = `cand_${candidateCount++}`;
  const div = document.createElement('div');
  div.innerHTML = `
  <hr>
  <label>Candidate Name:</label><input id='${cid}_name'>
  <label>Upload Photo:</label><input type='file' id='${cid}_photo' accept='image/*'>
  <label>Symbol Name:</label><input id='${cid}_symbolname'>
  <label>Upload Symbol Image:</label><input type='file' id='${cid}_symbol' accept='image/*'>`;
  container.appendChild(div);
}

async function saveElection() {
  const title = document.getElementById('etitle').value.trim();
  const pos = document.getElementById('eposition').value.trim();
  const startInput = document.getElementById('estart').value;
  const endInput = document.getElementById('eend').value;

  if (!title || !pos || !startInput || !endInput)
    return alert('Please fill all fields including start and end time.');

  const startTime = new Date(startInput).getTime();
  const endTime = new Date(endInput).getTime();
  const now = Date.now();

  if (startTime >= endTime) return alert('End time must be after start time.');

  const candDivs = document.querySelectorAll('#candidates > div');
  if (candDivs.length < 1) return alert('Please add at least one candidate.');

  const cands = [];
  for (const div of candDivs) {
    const name = div.querySelector('input[id$="_name"]').value.trim();
    const symbolName = div.querySelector('input[id$="_symbolname"]').value.trim();
    const photoFile = div.querySelector('input[id$="_photo"]').files[0];
    const symbolFile = div.querySelector('input[id$="_symbol"]').files[0];
    if (!name || !symbolName || !photoFile || !symbolFile)
      return alert('Please fill all candidate details.');
    cands.push({
      id: Math.random().toString(36).slice(2),
      name,
      symbolName,
      photo: photoFile,
      symbolImg: symbolFile,
      votes: 0,
    });
  }

  let status = 'open';
  if (now < startTime) status = 'upcoming';
  if (now > endTime) status = 'closed';

  const newElection = {
    id: Date.now(),
    title,
    position: pos,
    status,
    startTime,
    endTime,
    candidates: cands,
  };

  elections.push(newElection);
  await saveData();
  alert('Election created successfully!');
  showAdminDashboard();
}


function renderElectionsAdmin() {
  if (elections.length === 0) return '<p>No elections created yet.</p>';
  return elections.map(e => `
  <div style="border:1px solid #ccc; padding:10px; margin:10px;">
    <b>${e.title}</b> (${e.position}) [${e.status}]
    <button onclick='toggleStatus(${e.id})'>${e.status === 'open' ? 'Close' : 'Open'}</button>
    <button onclick='deleteElection(${e.id})'>Delete</button>
    <button onclick='viewResults(${e.id})'>View Results</button>
  </div>`).join('');
}

function viewResults(id) {
  const e = elections.find(x => x.id == id);
  if (!e) return alert('Election not found');

  const sortedCandidates = [...e.candidates].sort((a, b) => b.votes - a.votes);

  app.innerHTML = `
  <h2>Results: ${e.title} (${e.position})</h2>
  ${sortedCandidates.map(c => `
    <div style="border:1px solid #ccc; margin:10px; padding:10px;">
      <img src='${getImageURL(c.photo)}' width='80' height='80' style='border-radius:50%;'><br>
      <b>${c.name}</b><br>
      Symbol: ${c.symbolName} <img src='${getImageURL(c.symbolImg)}' width='40'><br>
      <b>Votes:</b> ${c.votes}
    </div>`).join('')}
  <button onclick='showAdminDashboard()'>Back</button>`;
}

async function toggleStatus(id) {
  const e = elections.find(x => x.id == id);
  e.status = e.status === 'open' ? 'closed' : 'open';
  await saveData();
  showAdminDashboard();
}

async function deleteElection(id) {
  if (confirm('Delete this election?')) {
    elections = elections.filter(e => e.id != id);
    await saveData();
    showAdminDashboard();
  }
}

function showRegister() {
  app.innerHTML = `<h2>Register Voter</h2>
  <input id='uname' placeholder='Username'>
  <input id='upass' type='password' placeholder='Password'>
  <input id='uid' placeholder='ID Proof (e.g. Roll No.)'>
  <label>Upload Profile Image:</label>
  <input type='file' id='uimg' accept='image/*'>
  <button onclick='registerUser()'>Register</button>
  <button onclick='showLogin()'>Back</button>`;
}

async function registerUser() {
  const name = document.getElementById('uname').value.trim();
  const pass = document.getElementById('upass').value.trim();
  const idProof = document.getElementById('uid').value.trim();
  const imgFile = document.getElementById('uimg').files[0];

  if (!name || !pass || !idProof || !imgFile) return alert('Please fill all fields and upload an image');
  if (users.find(u => u.name === name)) return alert('User already exists');

  // Store File directly
  users.push({ name, pass, idProof, photo: imgFile, voted: {} });
  await saveData(); // persist user immediately
  alert('Registration successful!');
  showLogin();
}

function showUserLogin() {
  app.innerHTML = `<h2>User Login</h2>
  <input id='uname' placeholder='Username'>
  <input id='upass' type='password' placeholder='Password'>
  <button onclick='userLogin()'>Login</button>
  <button onclick='showLogin()'>Back</button>`;
}

async function userLogin() {
  const name = document.getElementById('uname').value.trim();
  const pass = document.getElementById('upass').value.trim();

  await loadDataFromDB(); // get latest users
  const u = users.find(x => x.name === name && x.pass === pass);
  if (!u) return alert('Invalid username or password');

  // assign role to user
  loggedUser = { ...u, role: 'user' };

  // store minimal info in meta
  await putMeta('loggedUser', { name: loggedUser.name, role: 'user' });
  await saveData();

  showUserDashboard();
}


async function showUserDashboard() {
  await autoUpdateElectionStatus();
  const openElections = elections.filter(e => e.status === 'open');
  const closedElections = elections.filter(e => e.status === 'closed');
  const upcomingElections = elections.filter(e => e.status === 'upcoming');

  const username = loggedUser?.name || 'User';
  const role = loggedUser?.role || 'user';


  app.innerHTML = `
   <h2>Welcome, ${username}! (${role}) 👋</h2>


    <h3>Upcoming Elections</h3>
    ${upcomingElections.length
      ? upcomingElections.map(e => `
        <div style="border:1px solid #ccc; padding:10px; margin:10px;">
          <b>${e.title}</b> (${e.position})<br>
          <small>Starts: ${new Date(e.startTime).toLocaleString()}</small><br>
          <small>Ends: ${new Date(e.endTime).toLocaleString()}</small>
        </div>`).join('')
      : '<p>No upcoming elections.</p>'}

    <h3>Active Elections</h3>
    ${openElections.length
      ? openElections.map(e => `
        <div style="border:1px solid #ccc; padding:10px; margin:10px;">
          <b>${e.title}</b> (${e.position})<br>
          <small>Ends: ${new Date(e.endTime).toLocaleString()}</small><br>
          <button onclick='votePage(${e.id})'>Vote</button>
        </div>`).join('')
      : '<p>No active elections right now.</p>'}

    <h3>Closed Elections (Results)</h3>
    ${closedElections.length
      ? closedElections.map(e => `
        <div style="border:1px solid #ccc; padding:10px; margin:10px;">
          <b>${e.title}</b> (${e.position})
          <button onclick='viewResultsUser(${e.id})'>View Results</button>
        </div>`).join('')
      : '<p>No closed elections yet.</p>'}

    <button onclick='logout()'>Logout</button>`;
}

function viewResultsUser(id) {
  const e = elections.find(x => x.id == id);
  if (!e) return alert('Election not found');

  const sortedCandidates = [...e.candidates].sort((a, b) => b.votes - a.votes);
  const totalVotes = sortedCandidates.reduce((sum, c) => sum + c.votes, 0);
  const winnerId = sortedCandidates[0]?.id;

  app.innerHTML = `
    <h2>Results: ${e.title} (${e.position})</h2>
    ${sortedCandidates.map(c => `
      <div style="border:1px solid #ccc; margin:10px; padding:10px; 
          ${c.id === winnerId ? 'background:#d4edda;' : ''}">
        <img src='${getImageURL(c.photo)}' width='80' height='80' style='border-radius:50%;'><br>
        <b>${c.name}</b><br>
        Symbol: ${c.symbolName} <img src='${getImageURL(c.symbolImg)}' width='40'><br>
        <b>Votes:</b> ${c.votes} (${totalVotes > 0 ? ((c.votes / totalVotes) * 100).toFixed(1) : 0}%)
        ${c.id === winnerId ? '<br><b style="color:green;">Winner</b>' : ''}
      </div>`).join('')}
    <button onclick='showUserDashboard()'>Back</button>`;
}

function votePage(id) {
  const e = elections.find(x => x.id == id);
  if (!loggedUser) return alert('Please login first');
  if (loggedUser.voted && loggedUser.voted[id]) return alert('You already voted');

  app.innerHTML = `<h2>${e.title} - ${e.position}</h2>
  <div class='candidate-list'>${e.candidates.map(c => `<div class='candidate-card'>
  <img src='${getImageURL(c.photo)}' width='80'><h3>${c.name}</h3>
  <img src='${getImageURL(c.symbolImg)}' width='50'><p>${c.symbolName}</p>
  <input type='radio' name='vote' value='${c.id}'>
  </div>`).join('')}</div>
  <button onclick='castVote(${id})'>Submit Vote</button>
  <button onclick='showUserDashboard()'>Back</button>`;
}

async function castVote(eid) {
  const e = elections.find(x => x.id == eid);
  const choice = document.querySelector('input[name=vote]:checked');
  if (!choice) return alert('Select a candidate');
  const c = e.candidates.find(x => x.id == choice.value);
  c.votes = (c.votes || 0) + 1;

  // mark that current logged user voted (update in users array)
  const uIndex = users.findIndex(u => u.name === loggedUser.name);
  if (uIndex !== -1) {
    users[uIndex].voted = users[uIndex].voted || {};
    users[uIndex].voted[eid] = true;
    loggedUser = users[uIndex]; // refresh loggedUser object
  } else {
    // fallback if users array isn't synced for some reason
    loggedUser.voted = loggedUser.voted || {};
    loggedUser.voted[eid] = true;
  }

  await saveData(); // persist both elections & users changes
  alert('Vote submitted');
  showUserDashboard();
}

async function logout() {
  loggedUser = null;
  await saveData();
  showLogin();
}

// autumatic election status update 
async function autoUpdateElectionStatus() {
  const now = Date.now();
  let updated = false;
  for (const e of elections) {
    if (e.startTime && e.endTime) {
      if (now < e.startTime && e.status !== 'upcoming') {
        e.status = 'upcoming'; updated = true;
      } else if (now >= e.startTime && now <= e.endTime && e.status !== 'open') {
        e.status = 'open'; updated = true;
      } else if (now > e.endTime && e.status !== 'closed') {
        e.status = 'closed'; updated = true;
      }
    }
  }
  if (updated) await saveData();
}

async function showAdminDashboard() {
  await autoUpdateElectionStatus();
  document.getElementById('app').innerHTML = `<h2>Admin Dashboard</h2>
  <button onclick="createElectionForm()">Create Election</button>
  <button onclick="viewVoters()">View Voters</button>
  <div id='elist'>${renderElectionsAdmin()}</div>
  <button onclick="logout()">Logout</button>`;
}

// async function showUserDashboard() {
//   await autoUpdateElectionStatus();
//   const openElections = elections.filter(e => e.status === 'open');
//   const closedElections = elections.filter(e => e.status === 'closed');
//   const upcomingElections = elections.filter(e => e.status === 'upcoming');

//   app.innerHTML = `
//     <h2>Upcoming Elections</h2>
//     ${upcomingElections.length
//       ? upcomingElections.map(e => `
//         <div style="border:1px solid #ccc; padding:10px; margin:10px;">
//           <b>${e.title}</b> (${e.position})<br>
//           <small>Starts: ${new Date(e.startTime).toLocaleString()}</small><br>
//           <small>Ends: ${new Date(e.endTime).toLocaleString()}</small>
//         </div>`).join('')
//       : '<p>No upcoming elections.</p>'}

//     <h2>Active Elections</h2>
//     ${openElections.length
//       ? openElections.map(e => `
//         <div style="border:1px solid #ccc; padding:10px; margin:10px;">
//           <b>${e.title}</b> (${e.position})<br>
//           <small>Ends: ${new Date(e.endTime).toLocaleString()}</small><br>
//           <button onclick='votePage(${e.id})'>Vote</button>
//         </div>`).join('')
//       : '<p>No active elections right now.</p>'}

//     <h2>Closed Elections (Results)</h2>
//     ${closedElections.length
//       ? closedElections.map(e => `
//         <div style="border:1px solid #ccc; padding:10px; margin:10px;">
//           <b>${e.title}</b> (${e.position})
//           <button onclick='viewResultsUser(${e.id})'>View Results</button>
//         </div>`).join('')
//       : '<p>No closed elections yet.</p>'}

//     <button onclick='logout()'>Logout</button>`;
// }


// ---------------------------
// Run the app
// ---------------------------
initApp();
